$(document).ready(function(){
	$("#searchGuitar").click(function(){		
		$.ajax({
			type:"POST",
			url:"guitar_find",
			dateType:"json",
			contentType:"application/x-www-form-urlencoded; charset=UTF-8",
			data:$("#guitarForm").serialize(),
			success:function(data){
				$("#guitarTable").hide();
				$("#guitarList").show();				
				var data1=JSON.parse(data)
				if(data1.list==null || data1.list==""){
					$("#guitarListHead").hide();					
					var c=$("#guitarMessage").append("<tr id='message'></tr>");
					c.append("<td>未检索到这种吉他</td>");
				}
				else{
				$.each(data1.list,function(i,guitar){
					
					$("#1").append("<td>"+guitar.guitarSpec.builder+"</td>");
					$("#2").append("<td>"+guitar.guitarSpec.model+"</td>");
					$("#3").append("<td>"+guitar.guitarSpec.type+"</td>");
					$("#4").append("<td>"+guitar.guitarSpec.backWood+"</td>");
					$("#5").append("<td>"+guitar.guitarSpec.topWood+"</td>");
					$("#6").append("<td>"+guitar.price+"</td>");
					$("#7").append("<td>"+guitar.serialNumber+"</td>");
					});
				}
				},		
			error:function(){
				alert("页面已丢失");
			}
		});
	});
	$("guitarTable").hide();
})
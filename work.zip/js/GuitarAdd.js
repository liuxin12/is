$(document).ready(function(){
$("#guitarAdd").click(function(){
		alert("hh");
		$.ajax({
			type:"POST",
			url:"guitar_add",
			dateType:"json",
			contentType:"application/x-www-form-urlencoded; charset=UTF-8",
			data:$("#guitar").serialize(),
			success:function(data){
				$.html("<p>添加成功</p>").css(color,red);
			},
			error:function(data){
				$.html("<p>添加失败</p>").css(color,red);
			}
		})
	})
})	